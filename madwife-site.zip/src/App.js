import React from "react";

export default function MadWifePage() {
  return (
    <div className="min-h-screen bg-[#fff0f0] text-gray-900 font-sans p-6 flex flex-col items-center justify-center">
      <div className="max-w-2xl w-full text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">$MADWIFE 👰💢</h1>
        <p className="text-lg md:text-xl mb-6 italic">
          Every man has one. Now every wallet should too.
        </p>

        <img
          src="/madwife-logo.png"
          alt="$MADWIFE logo"
          className="w-48 h-48 mx-auto mb-6 rounded-full shadow-lg"
        />

        <p className="mb-6 text-md md:text-lg">
          She slaps when you buy. Screams when you sell. Yells when you check the chart. $MADWIFE is more than a memecoin — she's a lifestyle. Powered by pure rage and deployed on Solana. Join the drama before she finds out.
        </p>

        <a
          href="https://pump.fun/46YCZghV55N3cjL5x9H2YMpEkQBVdfVtRnQwEU8Lpump"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-xl shadow-md transition duration-200 mb-4"
        >
          💸 Buy $MADWIFE Now
        </a>

        <div className="mt-6">
          <a
            href="https://x.com/yourmadwife"
            target="_blank"
            rel="noopener noreferrer"
            className="text-pink-700 underline text-md"
          >
            Follow us on X
          </a>
        </div>

        <footer className="mt-12 text-xs text-gray-500">
          Not financial advice. Probably relationship advice.
        </footer>
      </div>
    </div>
  );
}